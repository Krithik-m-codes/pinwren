Pinwren export of "Demo site", 2026-11-02T09:11:39.090Z

project.json   the project's settings (secrets left out)
labels.json    the project's labels
feedback.json  every item with its comments, activity and file list
assets/        screenshots, attachments and replays, by item number
